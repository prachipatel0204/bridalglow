// BridalGlow - JavaScript Data & App Management (No Database Required)

const artistsData = [
    {
        id: 1,
        name: "Priya Makeup Studio",
        category: "Makeup",
        location: "Mumbai",
        rating: 4.9,
        reviews_count: 34,
        price_range: "₹5,000 - ₹25,000",
        price_val: 15000,
        experience: "8 years",
        image: "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=600&q=80",
        description: "Professional bridal makeup artist specializing in natural HD and airbrush makeup for royal looks."
    },
    {
        id: 2,
        name: "Mehndi Magic by Anjali",
        category: "Mehndi",
        location: "Delhi",
        rating: 4.8,
        reviews_count: 29,
        price_range: "₹3,000 - ₹15,000",
        price_val: 9000,
        experience: "6 years",
        image: "https://images.unsplash.com/photo-1610030469983-98e550d6193c?auto=format&fit=crop&w=600&q=80",
        description: "Expert bridal mehndi artist with intricate traditional Indian and modern Arabic fusion designs."
    },
    {
        id: 3,
        name: "Studio Royal Photography",
        category: "Photography",
        location: "Chennai",
        rating: 5.0,
        reviews_count: 42,
        price_range: "₹20,000 - ₹75,000",
        price_val: 45000,
        experience: "10 years",
        image: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?auto=format&fit=crop&w=600&q=80",
        description: "Candid wedding photography and cinematic pre-wedding shoots capturing timeless memories."
    },
    {
        id: 4,
        name: "Kavya Hair & Styling",
        category: "Bridal Wear",
        location: "Bangalore",
        rating: 4.7,
        reviews_count: 18,
        price_range: "₹4,000 - ₹18,000",
        price_val: 11000,
        experience: "5 years",
        image: "https://images.unsplash.com/photo-1560066984-138dadb4c035?auto=format&fit=crop&w=600&q=80",
        description: "Luxury bridal saree draping, hair extensions, floral hairstyles, and designer accessory styling."
    }
];

// App State
let state = {
    wishlist: JSON.parse(localStorage.getItem('bg_wishlist')) || [],
    bookings: JSON.parse(localStorage.getItem('bg_bookings')) || []
};

// DOM Content Loaded Initializer
document.addEventListener('DOMContentLoaded', () => {
    renderCategories();
    renderArtists(artistsData);
    renderDashboardBookings();
    updateWishlistBadge();

    // Event Listeners for Filters
    document.getElementById('search-input').addEventListener('input', applyFilters);
    document.getElementById('category-filter').addEventListener('change', applyFilters);
    document.getElementById('city-filter').addEventListener('change', applyFilters);
    document.getElementById('price-sort').addEventListener('change', applyFilters);
});

// Category Rendering
function renderCategories() {
    const categories = [
        { name: "Makeup", icon: "💄", count: "12 Artists" },
        { name: "Mehndi", icon: "🎨", count: "9 Artists" },
        { name: "Photography", icon: "📸", count: "15 Studios" },
        { name: "Bridal Wear", icon: "👗", count: "8 Stylists" }
    ];

    const container = document.getElementById('categories-container');
    container.innerHTML = categories.map(cat => `
        <div onclick="filterByCategory('${cat.name}')" class="bg-rose-50/50 hover:bg-pink-100/60 border border-rose-100 p-6 rounded-2xl text-center cursor-pointer transition-all">
            <div class="text-3xl mb-2">${cat.icon}</div>
            <h3 class="font-bold text-slate-800 text-sm sm:text-base">${cat.name}</h3>
            <p class="text-xs text-slate-500 mt-1">${cat.count}</p>
        </div>
    `).join('');
}

// Artist Card Rendering
function renderArtists(data) {
    const grid = document.getElementById('artists-grid');
    if (data.length === 0) {
        grid.innerHTML = `<div class="col-span-full text-center py-12 text-slate-400">No artists match your criteria.</div>`;
        return;
    }

    grid.innerHTML = data.map(artist => {
        const isWishlisted = state.wishlist.includes(artist.id);
        return `
            <div class="artist-card bg-white rounded-3xl overflow-hidden shadow-sm border border-slate-100 flex flex-col justify-between">
                <div>
                    <div class="relative h-48 overflow-hidden">
                        <img src="${artist.image}" alt="${artist.name}" class="w-full h-full object-cover">
                        <button onclick="toggleWishlist(${artist.id})" class="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center text-slate-600 hover:text-pink-600">
                            <i class="${isWishlisted ? 'fas text-pink-600' : 'far'} fa-heart"></i>
                        </button>
                    </div>
                    <div class="p-6">
                        <div class="flex justify-between items-start mb-2">
                            <div>
                                <span class="px-2.5 py-0.5 rounded-full text-[11px] font-semibold bg-rose-100 text-rose-700">${artist.category}</span>
                                <h3 class="font-bold text-lg text-slate-900 mt-1">${artist.name}</h3>
                            </div>
                            <div class="flex items-center text-amber-500 text-sm font-semibold">
                                <i class="fas fa-star text-xs mr-1"></i> ${artist.rating}
                            </div>
                        </div>
                        <p class="text-xs text-slate-500 mb-4 line-clamp-2">${artist.description}</p>
                        <div class="text-xs text-slate-600 space-y-1">
                            <div><i class="fas fa-map-marker-alt text-pink-500 mr-2"></i>${artist.location}</div>
                            <div><i class="fas fa-tag text-pink-500 mr-2"></i>${artist.price_range}</div>
                        </div>
                    </div>
                </div>
                <div class="p-6 pt-0">
                    <button onclick="openBookingModal(${artist.id}, '${artist.name}')" class="w-full bg-slate-900 hover:bg-pink-600 text-white font-medium py-2.5 rounded-xl text-sm transition-colors">Book Now</button>
                </div>
            </div>
        `;
    }).join('');
}

// Filtering Logic
function applyFilters() {
    const search = document.getElementById('search-input').value.toLowerCase();
    const category = document.getElementById('category-filter').value;
    const city = document.getElementById('city-filter').value;
    const sort = document.getElementById('price-sort').value;

    let filtered = artistsData.filter(artist => {
        const matchesSearch = artist.name.toLowerCase().includes(search) || artist.description.toLowerCase().includes(search);
        const matchesCategory = category === 'All' || artist.category === category;
        const matchesCity = city === 'All' || artist.location === city;
        return matchesSearch && matchesCategory && matchesCity;
    });

    if (sort === 'low-high') {
        filtered.sort((a, b) => a.price_val - b.price_val);
    } else if (sort === 'high-low') {
        filtered.sort((a, b) => b.price_val - a.price_val);
    }

    renderArtists(filtered);
}

function filterByCategory(catName) {
    document.getElementById('category-filter').value = catName;
    applyFilters();
    document.getElementById('artists').scrollIntoView({ behavior: 'smooth' });
}

// Wishlist Logic
function toggleWishlist(id) {
    if (state.wishlist.includes(id)) {
        state.wishlist = state.wishlist.filter(item => item !== id);
    } else {
        state.wishlist.push(id);
    }
    localStorage.setItem('bg_wishlist', JSON.stringify(state.wishlist));
    updateWishlistBadge();
    applyFilters();
}

function updateWishlistBadge() {
    document.getElementById('wishlist-badge').textContent = state.wishlist.length;
}

// Modal & Booking Logic
function openBookingModal(id, name) {
    document.getElementById('booking-artist-id').value = id;
    document.getElementById('booking-artist-name').textContent = `Artist: ${name}`;
    document.getElementById('booking-modal').classList.remove('hidden');
}

function closeBookingModal() {
    document.getElementById('booking-modal').classList.add('hidden');
}

function handleBookingSubmit(event) {
    event.preventDefault();
    const newBooking = {
        id: 'BG-2026-' + Math.floor(1000 + Math.random() * 9000),
        artistName: document.getElementById('booking-artist-name').textContent.replace('Artist: ', ''),
        userName: document.getElementById('user-name').value,
        package: document.getElementById('booking-package').value,
        date: document.getElementById('booking-date').value,
        time: document.getElementById('booking-time').value,
        status: 'Confirmed'
    };

    state.bookings.unshift(newBooking);
    localStorage.setItem('bg_bookings', JSON.stringify(state.bookings));
    renderDashboardBookings();
    closeBookingModal();
    alert(`🎉 Booking Confirmed! Booking Code: ${newBooking.id}`);
}

// Dashboard Rendering
function renderDashboardBookings() {
    const list = document.getElementById('dashboard-bookings-list');
    document.getElementById('booking-count-badge').textContent = `${state.bookings.length} Bookings`;

    if (state.bookings.length === 0) {
        list.innerHTML = `<p class="text-sm text-slate-500 italic py-4">No active bookings found. Select an artist above to book!</p>`;
        return;
    }

    list.innerHTML = state.bookings.map(b => `
        <div class="bg-white p-4 rounded-xl shadow-sm border border-rose-100 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
                <span class="text-xs font-bold text-pink-600 bg-pink-50 px-2 py-0.5 rounded">${b.id}</span>
                <h4 class="font-bold text-slate-900 mt-1">${b.artistName}</h4>
                <p class="text-xs text-slate-500">${b.package} • ${b.date} (${b.time})</p>
            </div>
            <span class="px-3 py-1 bg-emerald-100 text-emerald-700 font-medium text-xs rounded-full">${b.status}</span>
        </div>
    `).join('');
}
