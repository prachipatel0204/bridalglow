# BridalGlow — Bridal Services Platform
**Task ID:** WD-MAT-003  
**Student Code:** DAS-MAT-003  
**Domain:** Bridal Services & Wedding  
**Company:** Data Alcott Systems  
**Internship:** Free Web Development Internship Online  
**Task Submission Link:** https://www.freeinternships.in/blog/

---

## 📌 Project Overview
BridalGlow is a fully responsive frontend web application connecting brides-to-be with premier wedding artists including makeup artists, mehndi specialists, photographers, and hairstylists. Built using HTML5, CSS3, Tailwind CSS, and pure JavaScript with LocalStorage for client-side data management.

## 🚀 Key Features
- **Artist Directory & Filtering:** Search by category, city, keywords, or price tier.
- **Client-side Booking System:** Instant appointment confirmation with unique booking code generation (`BG-2026-XXXX`).
- **Wishlist & Favorites:** Save preferred service providers to LocalStorage.
- **User Dashboard:** View booking history and active appointment statuses.
- **Responsive Design:** Optimized for Desktop, Tablet, and Mobile devices.

## 📁 File Structure
- `index.html` - Semantic HTML structure & Modals
- `style.css` - Custom styling & scrollbar design
- `script.js` - JavaScript state controller & dynamic DOM rendering
- `README.md` - Documentation and project description

## 💻 Setup Instructions
1. Clone or download this repository.
2. Open `index.html` in any modern browser.
